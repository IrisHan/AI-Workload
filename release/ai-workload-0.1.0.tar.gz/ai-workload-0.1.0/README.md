# AI Workload 0.1.0

Runnable package for macOS and Linux. Python 3.11 or newer is required. Node.js is not required. Windows and Docker are not supported.

The application is still in development. Version 1.0 is planned for 2027.

```bash
bash install.sh
bash start.sh
```

Open http://127.0.0.1:8666 . API reference: http://127.0.0.1:8666/docs .

`bash start.sh` listens on 127.0.0.1 port 8666. Choose another port with `PORT=9000 bash start.sh`. Stop with `bash stop.sh`. Status is ` .venv/bin/python scripts/service.py status`.

The database file is `data/planner.db`. `install.sh` creates it from `database/bundle/` when the file is absent. Set `DATABASE_URL=sqlite:////absolute/path/planner.db` before start to use another file. There is no other configuration file.
