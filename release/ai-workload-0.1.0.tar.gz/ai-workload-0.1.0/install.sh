#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11+ required; set PYTHON=/path/to/python3.11")
try:
    import pyexpat, sqlite3
except ImportError as exc:
    raise SystemExit("This Python cannot import pyexpat or sqlite3: %s" % exc)
PY
"$PYTHON" -m venv .venv
.venv/bin/python -m pip install -r backend/requirements.lock
.venv/bin/python -m pip install --no-deps -e './backend'
bash scripts/init_db.sh
echo
echo "Installed. Start with: bash start.sh"
echo "Open http://127.0.0.1:8666"
